<?php
$nome = $_POST["nome"];
$idade = $_POST["idade"];
$senha = $_POST["senha"];

if ($idade < 12) {
    $classificacao = "Criança";
} elseif ($idade <= 17) {
    $classificacao = "Adolescente";
} else {
    $classificacao = "Adulto";
}

$tamanho = strlen($senha);
if ($tamanho < 5) {
    $nivel = "Password fraca";
} elseif ($tamanho <= 8) {
    $nivel = "Password média";
} else {
    $nivel = "Password forte";
}

echo "<p>Olá, <span style= >$nome!</span></p>";
echo "Classificação etária: $classificacao.<br>";
echo "Nível da password: $nivel.";
?>
